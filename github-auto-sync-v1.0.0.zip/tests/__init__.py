"""
GitHub Auto Sync 测试包

包含所有单元测试和集成测试。
"""

__version__ = "0.1.0"
